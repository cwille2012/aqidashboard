var engine = require('engine.io');
var server = engine.listen(3001); //waiting for client to connect

//if connected to client AND redis then do socket.send

console.log('handlers.js started');

server.on('connection', function(socket) {
    function sendData() {
        var datetime = new Date();
        socket.send(datetime);
    }
    sendData();
    setInterval(sendData, 2000);
});